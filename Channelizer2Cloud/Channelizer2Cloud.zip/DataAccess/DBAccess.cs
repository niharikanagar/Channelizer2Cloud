﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Channelizer2Cloud.Models;
using Channelizer2Cloud.Data;
using System.Web.Mvc;
using Channelizer2Cloud.ViewModel;

namespace Channelizer2Cloud.DataAccess
{
    public class DBAccess
    {
        private ChannelizerAppContext db = new ChannelizerAppContext();

        public void SaveUserLoginDeviceInfo(UserLoginDeviceInfo json)
        {
            db.UserLoginDeviceInfoes.Add(json);
            db.SaveChanges();
        }

        public void SaveEventLogError(EventLog json)
        {
            db.EventLogs.Add(json);
            db.SaveChanges();
        }
        public void SaveAuditLogInformation(Auditlog json)
        {
            db.Auditlogs.Add(json);
            db.SaveChanges();
        }

        public void SaveUserLogTimeInfo(User_LogTime json)
        {
            User_LogTime checksession = db.User_LogTime.Where(x => x.SessionId == json.SessionId).FirstOrDefault();
            if (checksession == null)
            {
                db.User_LogTime.Add(json);
            }
            else
            {
                checksession.LogOutTime = json.LogOutTime;
                checksession.Offline = json.Offline;
                db.Entry(checksession).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
        }

        public UserInformation GetUserfromUserName(string username)
        {
            return db.UserInformations.Where(x => x.UserName == username).FirstOrDefault();
        }
        public string UpdateUserPassword(string password, string username)
        {
            UserInformation userInformation = db.UserInformations.Where(x => x.UserName == username).FirstOrDefault();
            userInformation.Password = password;
            db.Entry(userInformation).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            return "Password saved Successfully";
        }

        public string SaveVendorInformation(Vendor vendor)
        {
            Vendor checkVendor = db.Vendors.Where(x => x.VendorName == vendor.VendorName).FirstOrDefault();
            if (checkVendor == null)
            {
                db.Vendors.Add(vendor);
            }
            else
            {
                return "Vendor Name Already Exists";
                // db.Entry(vendor).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
            return "Vendor saved Successfully";
        }

        public string SaveVendorProgram(Vendor_Program vendorProgram)
        {
            Vendor_Program checkVendorProgram = db.Vendor_Program.Where(x => x.VendorId == vendorProgram.VendorId && x.ProgramName == vendorProgram.ProgramName).FirstOrDefault();
            if (checkVendorProgram == null)
            {
                db.Vendor_Program.Add(vendorProgram);
            }
            else
            {
                db.Entry(vendorProgram).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
            return "Vendor Program saved Successfully";
        }

        public List<SelectListItem> GetVendorList(int? id)
        {
            if (id == null)
            {
                return db.Vendors.Select(x => new SelectListItem {
                    Value = x.Vendor_Id.ToString(),
                    Text = x.VendorName
                }).ToList();
            }
            else
            {
                return db.Vendors.Where(x => x.Vendor_Id == id).Select(x => new SelectListItem
                {
                    Value = x.Vendor_Id.ToString(),
                    Text = x.VendorName
                }).ToList();
            }

        }

        public List<Vendor_RegistrationFormField> GetSavedFormData(int? programId, int? vendorId)
        {
            return db.Vendor_RegistrationFormField.Where(x => x.VendorId == vendorId && x.VendorProgramId == programId).ToList();
        }

        public string SaveReferenceDataList(List<ReferenceDataListItem> referenceDataListItems)
        {
            foreach (ReferenceDataListItem referenceDataListItem in referenceDataListItems)
            {
                ReferenceDataListItem checkReferenceDataListItem = db.ReferenceDataListItems.Where(x => x.ProgramId == referenceDataListItem.ProgramId && x.ReferenceDataListId == referenceDataListItem.ReferenceDataListId && x.DisplayValue == referenceDataListItem.DisplayValue).FirstOrDefault();
                if (checkReferenceDataListItem == null)
                {
                    db.ReferenceDataListItems.Add(referenceDataListItem);
                }
                else
                {
                    db.Entry(checkReferenceDataListItem).State = System.Data.Entity.EntityState.Modified;
                }
                db.SaveChanges();
            }
            return "ReferenceDataListItem saved Successfully";
        }

        public string SaveVendorRegistrtaionFormField(Vendor_RegistrationFormField vendorRegistrationFormField)
        {
            Vendor_RegistrationFormField checkVendorRegistrationFormField = db.Vendor_RegistrationFormField.Where(x => x.VendorProgramId == vendorRegistrationFormField.VendorProgramId && x.FieldTypeId == vendorRegistrationFormField.FieldTypeId && x.FieldName == vendorRegistrationFormField.FieldName).FirstOrDefault();
            if (checkVendorRegistrationFormField == null)
            {
                db.Vendor_RegistrationFormField.Add(vendorRegistrationFormField);
            }
            else
            {
               // checkVendorRegistrationFormField.
                db.Entry(checkVendorRegistrationFormField).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
            return "VendorRegistrationFormField saved Successfully";
        }

        public int SaveSaleRepInfo(MvsSalesRepresentative mvsSalesRepresentative) {
            MvsSalesRepresentative checkMvsSalesRepresentative = db.MvsSalesRepresentatives.Where(x => x.Email == mvsSalesRepresentative.Email || x.Phone == mvsSalesRepresentative.Phone).FirstOrDefault();
            if (checkMvsSalesRepresentative == null)
            {
                db.MvsSalesRepresentatives.Add(mvsSalesRepresentative);
            }
            else
            {
                mvsSalesRepresentative.MvsSalesRepresentative_Id = checkMvsSalesRepresentative.MvsSalesRepresentative_Id;
                db.Entry(checkMvsSalesRepresentative).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
            return mvsSalesRepresentative.MvsSalesRepresentative_Id;
        }
        public int SaveCustomerInfo(Customer customer) {
            Customer checkCustomer = db.Customers.Where(x => x.Name == customer.Name && x.Address1 == customer.Address1 && x.Country == customer.Country && x.State == customer.State && x.City == customer.City).FirstOrDefault();
            if (checkCustomer == null)
            {
                db.Customers.Add(customer);
            }
            else
            {
                customer.Customer_Id = checkCustomer.Customer_Id;
                db.Entry(checkCustomer).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
            return customer.Customer_Id;
        }
        public int SaveCustomerContactInfo(CustomerContact customerContact) {
            CustomerContact checkCustomerContact = db.CustomerContacts.Where(x => x.Email == customerContact.Email || x.Mobile == customerContact.Mobile).FirstOrDefault();
            if (checkCustomerContact == null)
            {
                db.CustomerContacts.Add(customerContact);
            }
            else
            {
                customerContact.CustomerContact_Id = checkCustomerContact.CustomerContact_Id;
                db.Entry(checkCustomerContact).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
            return customerContact.CustomerContact_Id;
        }

        public int SaveMvsDealInfo(Mvs_Deal mvs_Deal)
        {
            Mvs_Deal checkMvs_Deal = db.Mvs_Deal.Where(x => x.ProgramId == mvs_Deal.ProgramId && x.SalesRepId == mvs_Deal.SalesRepId && x.CustomerId == mvs_Deal.CustomerId && x.CustomerContactId == mvs_Deal.CustomerContactId && x.DealName == mvs_Deal.DealName).FirstOrDefault();
            if (checkMvs_Deal == null)
            {
                db.Mvs_Deal.Add(mvs_Deal);
            }
            else
            {
                db.Entry(checkMvs_Deal).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
            return mvs_Deal.Mvs_Deal_Id;
        }

        public List<SelectListItem> GetProgramList()
        {
            return db.Vendor_Program.Select(x => new SelectListItem
            {
                Value = x.Vendor_Program_Id.ToString(),
                Text = x.ProgramName
            }).ToList();

        }

        public Vendor GetVendorDetails(int? id)
        {

            return db.Vendors.Where(x => x.Vendor_Id == id).FirstOrDefault();

        }

        public Vendor_Program GetVendorProgramDetails(int? id)
        {

            return db.Vendor_Program.Where(x => x.Vendor_Program_Id == id).FirstOrDefault();


        }

        public Guid SaveUserInfo(UserInformation userinfo)
        {
            UserInformation checkUserInformation = db.UserInformations.Where(x => x.Email == userinfo.Email && x.Phone == userinfo.Phone).FirstOrDefault();
            if (checkUserInformation == null)
            {
                db.UserInformations.Add(userinfo);
            }
            else
            {
                userinfo.UserInformation_Id = checkUserInformation.UserInformation_Id;
                db.Entry(checkUserInformation).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
            return userinfo.UserInformation_Id;
        }

        public List<Mvs_Deal> GetAllRegistrations(Guid UserId)
        {
            return db.Mvs_Deal.Where(x => x.CreatedBy == UserId).ToList();
        }

        public List<Mvs_Deal> GetAllDeletedRegistrations(Guid UserId)
        {
            return db.Mvs_Deal.Where(x => x.CreatedBy == UserId && x.IsDeleted == true).ToList();
        }
        public string CreateRole(Roles roles)
        {
            Roles checkRoles = db.Roles.Where(x => x.RoleName == roles.RoleName).FirstOrDefault();
            if (checkRoles == null)
            {
                db.Roles.Add(roles);
                db.SaveChanges();
                return "Roles saved Successfully";
            }
            else
            {
                db.Entry(checkRoles).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return "RoleName Already Exists";
            }
        }

        public List<Roles> GetAllRoles()
        {
            return db.Roles.Where(x => x.IsDeleted == false).ToList();
        }

        public List<Vendor_RegistrationFormField> GetFormFields(int? programId)
        {

            return db.Vendor_RegistrationFormField.Where(x => x.IsActive == true && x.VendorProgramId == programId).ToList();
        }

        public string GetVendorLogobyProgramId(int? programId)
        {
            int? vendorId = db.Vendor_Program.Where(x => x.Vendor_Program_Id == programId).Select(x => x.VendorId).FirstOrDefault();
            return db.Vendors.Where(x => x.Vendor_Id == vendorId).Select(x => x.VendorLogo).FirstOrDefault();
        }

        public List<SelectListItem> GetReferenceDataListItem(int? programId,int? fieldId)
        {
           return db.ReferenceDataListItems.Where(x => x.ReferenceDataListId == fieldId && x.ProgramId == programId)
            .Select(x => new SelectListItem { Value = x.DisplayValue, Text = x.DisplayValue }).ToList();
        }

        public string SaveVendorDealInformation(Mvs_DealData dealData,int? dealId)
        {
            Mvs_DealData mvs_DealData = db.Mvs_DealData.Where(x => x.Mvs_DealId == dealId && x.DataKey == dealData.DataKey).FirstOrDefault();
            if (mvs_DealData == null)
            {
                db.Mvs_DealData.Add(dealData);
            }
            else
            {
                mvs_DealData.DataValue = dealData.DataValue;
                db.Entry(mvs_DealData).State = System.Data.Entity.EntityState.Modified;
            }
            db.SaveChanges();
            return "Deal Information saved Successfully";
        }

        public List<Mvs_DealData> GetDealDataInformation(int? dealId)
        {
            return db.Mvs_DealData.Where(x => x.Mvs_DealId == dealId).ToList();
        }

        public IQueryable<DealFormViewModel> GetDealWithFormField(int? dealId,int? programId)
        {
            return db.Vendor_RegistrationFormField.Where(y => y.VendorProgramId == programId).OrderBy(y => y.Sequence).Join(db.Mvs_DealData.Where(x => x.Mvs_DealId == dealId), x => x.FieldName, y => y.DataKey, (v, d) => new DealFormViewModel
        {
            FieldLabel = v.FieldLabel,
            DataValue = d.DataValue
        });
        }

        public int? GetCountFormfields(int? programId)
        {
            return db.Vendor_RegistrationFormField.Where(x => x.VendorProgramId == programId).Select(x => x.FieldName.Substring(8, x.FieldName.Length)).Select(int.Parse).ToList().Max();

        }


    }
}