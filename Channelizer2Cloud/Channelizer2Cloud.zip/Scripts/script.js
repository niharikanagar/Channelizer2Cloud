$('.s-loginform div input').on('change paste focus input click', function () {
    $('.s-center p').remove();
});