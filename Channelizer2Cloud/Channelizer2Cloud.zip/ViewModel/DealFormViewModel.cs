﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Channelizer2Cloud.ViewModel
{
    public class DealFormViewModel
    {
        public string FieldLabel { get; set; }
        public string DataValue { get; set; }//save as draft or submit
    }
}